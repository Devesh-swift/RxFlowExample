import RxFlow

enum AppStep: Step {
    case intro
    case details
    case setupFlow
    case finish
}
