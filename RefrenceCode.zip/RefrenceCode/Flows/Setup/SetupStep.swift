import RxFlow

enum SetupStep: Step {
    case step1
    case step2
    case exit
}
